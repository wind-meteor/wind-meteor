angular.module('nav.service', []).factory('navFty', function($http, $q, $window) {
	return {
		getAllData: function() {
			
		}
	}
});
