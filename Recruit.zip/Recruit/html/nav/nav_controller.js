angular.module('nav.controller',['nav.service']).controller('NavCtrl',function($scope,navFty){
	$scope.obj_ListCount={
		count:"6"
	}
});