angular.module('main.controller', []).controller('MainCtrl', function($scope, $window) {

});
