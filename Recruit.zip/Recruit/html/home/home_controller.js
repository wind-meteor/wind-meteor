angular.module('home.controller', []).controller('HomeCtrl', function($scope, $window) {

})
