angular.module('news.service', []).factory('NewsFty', function($http, $q) {
	return {

	}
});
