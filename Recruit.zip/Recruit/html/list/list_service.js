angular.module('list.service', []).factory('ListFty', function($http, $q) {
	return {

	}
});
