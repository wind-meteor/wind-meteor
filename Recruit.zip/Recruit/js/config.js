angular.module('config',[]).config(function($ionicConfigProvider){
	$ionicConfigProvider.platform.android.tabs.position("bottom");
})